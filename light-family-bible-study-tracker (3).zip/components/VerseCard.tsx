
import React from 'react';
import { VerseOfTheDay } from '../types';

interface VerseCardProps {
  verse: VerseOfTheDay | null;
  loading: boolean;
}

const VerseCard: React.FC<VerseCardProps> = ({ verse, loading }) => {
  if (loading) {
    return (
      <div className="w-full bg-white rounded-3xl p-8 text-center animate-pulse border border-yellow-100 shadow-xl">
        <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-4"></div>
        <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
      </div>
    );
  }

  if (!verse) return null;

  return (
    <div className="relative overflow-hidden w-full bg-white rounded-3xl p-8 md:p-12 text-center border-2 border-yellow-100 shadow-2xl glow-gold group">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-24 h-24 bg-yellow-50 rounded-br-full -z-10 transition-transform group-hover:scale-110 duration-700"></div>
      <div className="absolute bottom-0 right-0 w-32 h-32 bg-yellow-50 rounded-tl-full -z-10 transition-transform group-hover:scale-110 duration-700"></div>
      
      <div className="max-w-3xl mx-auto">
        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-[0.2em] mb-6">Verse of the Day</h3>
        <blockquote className="text-2xl md:text-3xl font-serif text-[#2D3748] mb-4 italic leading-tight">
          "{verse.verse}"
        </blockquote>
        <cite className="block text-lg font-bold text-[#D4AF37] not-italic mb-8">
          — {verse.reference}
        </cite>
        <div className="relative pt-6 border-t border-yellow-100">
          <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white px-4 text-yellow-300">
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
              <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM11 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2h-2z" />
            </svg>
          </span>
          <p className="text-gray-500 font-medium max-w-xl mx-auto leading-relaxed italic">
            {verse.reflection}
          </p>
        </div>
      </div>
    </div>
  );
};

export default VerseCard;
