
import React from 'react';
import { FamilyMember, DayOfWeek } from '../types';
import { DAYS_OF_WEEK } from '../constants';

interface TrackerTableProps {
  members: FamilyMember[];
  onToggle: (memberId: string, day: DayOfWeek) => void;
  onUpdateNote: (memberId: string, day: DayOfWeek, note: string) => void;
  onToggleAll: (memberId: string) => void;
}

const TrackerTable: React.FC<TrackerTableProps> = ({ members, onToggle, onUpdateNote, onToggleAll }) => {
  return (
    <table className="w-full border-collapse min-w-[900px]">
      <thead>
        <tr className="bg-yellow-50/50">
          <th className="text-left p-4 font-serif text-[#2D3748] border-b border-yellow-100">Family Member</th>
          {DAYS_OF_WEEK.map(day => (
            <th key={day} className="p-4 font-bold text-[#D4AF37] border-b border-yellow-100 text-center">
              {day}
            </th>
          ))}
          <th className="p-4 font-bold text-[#D4AF37] border-b border-yellow-100 text-center bg-yellow-100/30">
            Every Day
          </th>
        </tr>
      </thead>
      <tbody>
        {members.map(member => {
          const isAllChecked = DAYS_OF_WEEK.every(day => member.progress[day].completed);
          return (
            <tr key={member.id} className="hover:bg-yellow-50/30 transition-colors align-top">
              <td className="p-4 pt-6 font-semibold text-lg border-b border-yellow-50">{member.name}</td>
              {DAYS_OF_WEEK.map(day => {
                const isActive = member.progress[day].completed;
                return (
                  <td 
                    key={`${member.id}-${day}`} 
                    className="p-4 border-b border-yellow-50"
                  >
                    <div className="flex flex-col items-center gap-3">
                      <button
                        onClick={() => onToggle(member.id, day)}
                        className={`
                          w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300
                          ${isActive 
                            ? 'bg-yellow-400 text-white glow-light scale-110' 
                            : 'bg-gray-100 text-transparent hover:bg-yellow-100'}
                        `}
                      >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </button>
                      <input 
                        type="text"
                        placeholder="Reading..."
                        value={member.progress[day].note}
                        onChange={(e) => onUpdateNote(member.id, day, e.target.value)}
                        className={`
                          text-[10px] w-full max-w-[80px] text-center bg-white border rounded p-1 outline-none transition-all
                          ${isActive ? 'border-yellow-300 text-yellow-800 font-medium' : 'border-gray-100 text-gray-300'}
                          focus:border-yellow-500
                        `}
                      />
                    </div>
                  </td>
                );
              })}
              <td className="p-4 pt-6 text-center border-b border-yellow-50 bg-yellow-50/20">
                <button
                  onClick={() => onToggleAll(member.id)}
                  className={`
                    w-12 h-12 rounded-xl flex flex-col items-center justify-center transition-all duration-300 border-2 mx-auto
                    ${isAllChecked 
                      ? 'bg-yellow-500 border-yellow-600 text-white glow-light scale-105' 
                      : 'bg-white border-yellow-200 text-yellow-200 hover:border-yellow-400 hover:text-yellow-400'}
                  `}
                  title="Toggle All Days"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </button>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default TrackerTable;
