
import React, { useState } from 'react';
import { Reflection } from '../types';

interface ReflectionFeedProps {
  reflections: Reflection[];
  onAdd: (author: string, content: string) => void;
}

const ReflectionFeed: React.FC<ReflectionFeedProps> = ({ reflections, onAdd }) => {
  const [author, setAuthor] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !content.trim()) return;
    onAdd(author, content);
    setAuthor('');
    setContent('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1">
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-yellow-100 sticky top-8">
          <h2 className="text-2xl font-serif font-bold text-[#D4AF37] mb-4">Share a Reflection</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-500 mb-1 uppercase tracking-wider">Your Name</label>
              <input 
                type="text" 
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Who is sharing?"
                className="w-full border-2 border-yellow-100 rounded-xl p-3 focus:border-[#D4AF37] outline-none transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-500 mb-1 uppercase tracking-wider">Today's Lesson</label>
              <textarea 
                rows={4}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="What did you learn today?"
                className="w-full border-2 border-yellow-100 rounded-xl p-3 focus:border-[#D4AF37] outline-none transition-colors resize-none"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-[#D4AF37] text-white font-bold py-3 rounded-xl hover:bg-yellow-600 transition-all shadow-md transform hover:-translate-y-1"
            >
              Post to Fellowship Feed
            </button>
          </form>
        </div>
      </div>

      <div className="lg:col-span-2">
        <div className="bg-white/50 p-6 rounded-2xl shadow-inner border border-yellow-100 h-[600px] flex flex-col">
          <h2 className="text-2xl font-serif font-bold text-[#D4AF37] mb-6 flex items-center gap-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
            </svg>
            Fellowship Feed
          </h2>
          <div className="flex-1 overflow-y-auto space-y-6 pr-2">
            {reflections.length === 0 ? (
              <div className="h-full flex items-center justify-center text-gray-400 text-center italic">
                <p>No reflections yet. Be the first to share what you've learned!</p>
              </div>
            ) : (
              reflections.map((ref) => (
                <div key={ref.id} className="bg-white p-5 rounded-2xl shadow-sm border border-yellow-50 transition-all hover:shadow-md">
                  <div className="flex justify-between items-start mb-3">
                    <span className="font-bold text-[#D4AF37] text-lg">{ref.author}</span>
                    <span className="text-xs text-gray-400">
                      {new Date(ref.timestamp).toLocaleDateString()} at {new Date(ref.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-gray-700 leading-relaxed font-serif">"{ref.content}"</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReflectionFeed;
