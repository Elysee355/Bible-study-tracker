
import { GoogleGenAI, Type } from "@google/genai";
import { VerseOfTheDay } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const fetchVerseOfTheDay = async (): Promise<VerseOfTheDay> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Provide an inspiring Bible verse for a family study group. Return a short reflection to help them walk in the word together.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            verse: { type: Type.STRING },
            reference: { type: Type.STRING },
            reflection: { type: Type.STRING }
          },
          required: ["verse", "reference", "reflection"]
        }
      }
    });

    const data = JSON.parse(response.text);
    return data as VerseOfTheDay;
  } catch (error) {
    console.error("Error fetching verse:", error);
    return {
      verse: "Thy word is a lamp unto my feet, and a light unto my path.",
      reference: "Psalm 119:105",
      reflection: "God's word guides our steps through every season of life."
    };
  }
};
